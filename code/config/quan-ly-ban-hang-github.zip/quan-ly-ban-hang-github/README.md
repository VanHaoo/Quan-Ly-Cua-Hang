<div align="center">

# 🛒 HỆ THỐNG QUẢN LÝ BÁN HÀNG TẠI QUẦY

Đồ án môn **Hệ thống thông tin quản lý**

![PHP](https://img.shields.io/badge/PHP-8.x-777BB4?style=flat-square&logo=php&logoColor=white)
![MySQL](https://img.shields.io/badge/MySQL-Database-4479A1?style=flat-square&logo=mysql&logoColor=white)
![XAMPP](https://img.shields.io/badge/XAMPP-Local_Server-FB7A24?style=flat-square&logo=xampp&logoColor=white)

</div>

## Giới thiệu

Website mô phỏng quy trình bán hàng tại cửa hàng bán lẻ, hỗ trợ quản lý sản phẩm, bán hàng, thanh toán, hóa đơn, tồn kho và thống kê doanh thu. Hệ thống có hai vai trò là người quản lý và nhân viên bán hàng.

## Chức năng

Đăng nhập và phân quyền, quản lý sản phẩm, bán hàng tại quầy, tính tiền thừa, lập và in hóa đơn, hủy hóa đơn, hoàn trả tồn kho, cảnh báo hàng sắp hết và thống kê doanh thu.

## Công nghệ

PHP, MySQL, HTML, CSS, JavaScript và XAMPP.

## Cài đặt

1. Chép thư mục dự án vào `C:\xampp\htdocs\quan-ly-ban-hang`.
2. Bật Apache và MySQL trong XAMPP.
3. Mở `http://localhost/phpmyadmin` và nhập file `database.sql`.
4. Truy cập `http://localhost/quan-ly-ban-hang`.

## Tài khoản thử nghiệm

| Vai trò | Tài khoản | Mật khẩu |
|---|---|---|
| Quản lý | admin | 123456 |
| Nhân viên | nhanvien | 123456 |
